void main_func();
 int main() {
    main_func();
 return 0;
 }